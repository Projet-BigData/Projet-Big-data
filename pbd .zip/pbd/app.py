import pickle
from sklearn.feature_extraction.text import CountVectorizer
from nltk.tokenize import RegexpTokenizer
from nltk.stem import SnowballStemmer
import tkinter as tk
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
import pandas as pd

df = pd.read_csv("C:/Users/elsas/Music/newset.csv")

pipeline_ls= make_pipeline(CountVectorizer(tokenizer = RegexpTokenizer(r'[A-Za-z]+').tokenize,stop_words='english'), LogisticRegression())

trainX, testX, trainY, testY = train_test_split(df.domain, df.label, test_size=0.3, random_state=101)

pipeline_ls.fit(trainX,trainY)
pickle.dump(pipeline_ls, open('model.pkl', 'wb'))
loaded_model = pickle.load(open('model.pkl', 'rb'))

def predire():
    lien = lien_entry.get()
    tableau= [lien]
    resultat = loaded_model.predict(tableau)
    score = loaded_model.score(testX, testY)
    resultat_text.insert(tk.END, f"Ce lien est frauduleux" if resultat else f"Ce lien n'est pas frauduleux.\nTaux de précision: {score:.2f}")

# Création de la fenêtre principale
window = tk.Tk()

# Définition de la taille de la fenêtre
window.geometry("300x200")

# Création des champs de saisie et des libellés associés
lien_label = tk.Label(window, text="Entrer votre URL")
lien_entry = tk.Entry(window)

# Création du bouton de validation
valider_button = tk.Button(window, text="Predire", command=predire)

# Création du champ de texte pour afficher les résultats
resultat_text = tk.Text(window)

# Positionnement des éléments dans la fenêtre
lien_label.pack()
lien_entry.pack()
valider_button.pack()
resultat_text.pack()

# Lancement de la boucle principale de la fenêtre
window.mainloop()
